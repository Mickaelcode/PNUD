const {Db} = require('../BD/db')

class Admin{
    constructor(matricule,mdp){
        this.db=new Db
        this.matricule=matricule
        this.mdp=mdp
    }

    async connection(){
        try {
            return await this.db.selectByConstraint(this.role,['matricule','mot_de_passe'],[this.matricule,this.mdp],'=','&')!=0
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async insertUser(matricule,mdp,role){
        try {
            return await this.db.insert(role,['matricule','mdp'],[matricule,mdp])
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async updateUser(matricule,mdp,role){
        try {
            return await this.db.update(role,['matricule','mot_de_passe'],[matricule,mdp],['matricule'],[matricule])
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async deleteUser(matricule,role){
        try {
            return await this.db.delete(role,'matricule=$1',matricule)
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async selectUser(role){
        try {
            return await this.db.requette("select * from "+role+", personnel where personnel.matricule="+role+".matricule")
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async searchUser(matricule,role){
        try {
            return await this.db.requette("select * from "+role+", personnel where personnel.matricule="+role+".matricule && matricule="+matricule)
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }
}

module.exports = {Admin}