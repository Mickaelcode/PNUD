const {Db} = require('../BD/db')

class Ticket{
    constructor(){
        this.db=new Db
        this.table='ticket'
    }

    async insertTicket(code_ticket,id_nature,id_percepteur){
        try {
            const now = new Date();

            const jour = now.getDate();
            const mois = now.getMonth() + 1;
            const annee = now.getFullYear();

            const heures = now.getHours();
            const minutes = now.getMinutes();
            const secondes = now.getSeconds();

            const date_creation=(`${jour}/${mois}/${annee} ${heures}:${minutes}:${secondes}`);
            return await this.db.insert(this.table,['code_ticket','id_nature','id_percepteur','retour','date_creation'],[code_ticket,id_nature,id_percepteur,false,date_creation])
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }

    async ticketReturned(id_ticket){
        try {
            return await this.db.update(this.table,['retour'],[true],['id_ticket'],[id_ticket])
        } catch (err) {
            console.error('Error executing selectByConstraint query:', err.message);
            throw err;
        }
    }
}

module.exports = {Ticket}