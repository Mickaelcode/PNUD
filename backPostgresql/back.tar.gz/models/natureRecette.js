const {Db} = require('../BD/db')

class NatureRecette {
    constructor ({id, nom, montant, type, validation = true}) {
        this.id = id
        this.nom = nom
        this.montant = montant
        this.type = type
        this.validation = validation
        this.db = new Db()
    }
    async select() {
        try{
            const res = await this.db.selectAll('nature_recette')
            return res
        } catch(err) {
            console.error('error select des natureRecette')
            return false
        }
    }
    async insert() {
        try {
            const res = await this.db.insert('nature_recette', ['nom', 'montant', 'type', 'validation'], [this.nom, this.montant, this.type, this.validation])
            return res.length == 1
        } catch (error) {
            console.error('erreur enregistrement nature recette')
            return false
        }
    }

    async update() {
        try{
            const res = await this.db.update('nature_recette', ['nom', 'montant', 'type'], [this.nom, this.montant, this.type], ['id_nature'], [this.id])
            return res.length === 1
        } catch (error) {
            console.error('erreur modification nature de recette', error.message)
            return false
        }
    }
}

module.exports = {NatureRecette}

