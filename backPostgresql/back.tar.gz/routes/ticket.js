const router = require('express').Router();
const { insertTicket,ticketReturned } = require('../controllers/controllerTicket')

router.post('./', insertTicket,ticketReturned)

module.exports = router