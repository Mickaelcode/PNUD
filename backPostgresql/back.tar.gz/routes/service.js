const router = require('express').Router();
const { insertService,updateService,deleteService,selectService } = require('../controllers/controllerService')

router.post('./', insertService,updateService,deleteService,selectService)

module.exports = router