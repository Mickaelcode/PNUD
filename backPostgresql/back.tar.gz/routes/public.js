const router = require('express').Router();
const {insertPublic,insertPublicRequest,validatePublicRequest} = require('../controllers/controllerPublic')

router.post('./',insertPublic,insertPublicRequest,validatePublicRequest)

module.exports = router