const router = require('express').Router();
const {insertNatureRecette, updateNatureRecette,getAllNature, deleteNature} = require('../controllers/natureRecette'); 

router.post('/', insertNatureRecette)
router.post('/delete', deleteNature)
router.post('update', updateNatureRecette)
router.get('/', getAllNature)

module.exports = router