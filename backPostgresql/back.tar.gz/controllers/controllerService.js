const {Service} = require ('../models/service')

const service= new Service()

const insertService=async(req,res)=>{
    const cin=req.body.cin
    const id_nature=req.body.id_nature


    const result= await service.insertPublic(id_nature,cin)

    if (result) {
        res.status(200).json({
            code : 200,
            message : 'insertion d\'utilisateur réussie'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur lors de l\'insertion de l\'utilisateur'
        })
    }
}




const selectService=async(req,res)=>{

    const result= await service.selectUser()

    if (result) {
        res.status(200).json({
            code : 200,
            message : 'selection  réussie'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur lors de la selection '
        })
    }
}

const deleteService=async(req,res)=>{
    const id_service=req.body.id_service

    const result= await service.deleteService(id_service)

    if (result) {
        res.status(200).json({
            code : 200,
            message : 'suppression réussie'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur lors de la suppression '
        })
    }
}

const updateService=async(req,res)=>{
    const id_nature=req.body.id_nature
    const cin=req.body.cin
    const id_service=req.body.id_service

    const admin= new Admin()
    const result= await admin.updateService(id_nature,cin,id_service)

    if (result) {
        res.status(200).json({
            code : 200,
            message : 'modification réussie'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur lors de la modification'
        })
    }
}

module.exports = {insertService,updateService,selectService,deleteService}