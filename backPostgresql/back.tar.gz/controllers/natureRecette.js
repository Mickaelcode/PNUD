const { json } = require('express')
const {NatureRecette} = require('../models/natureRecette')

const insertNatureRecette = async(req, res) => {
    const nom = req.body.nom
    const montant = req.body.montant
    const type = req.body.type
    const natureRecette = new NatureRecette({nom, montant, type})
    const result = await natureRecette.insert()
    if(result) {
        res.status(200).json({
            code : 200,
            message : 'OK'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur insertion nature'
        })
    }
}

const updateNatureRecette = async (req, res) => {
    const nom = req.body.nom
    const montant = req.body.montant
    const type = req.body.type
    const id = req.body.id
    const natureRecette = new NatureRecette({nom, montant, type, id})
    const result = await natureRecette.update()
    if(result) {
        res.status(200).json({
            code : 200,
            message : 'OK'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur update nature'
        })
    }
}

const deleteNature = async (req, res) => {
    const validation = req.body.validation
    const id = req.body.id
    const natureRecette = new NatureRecette({validation, id})
    const result = await natureRecette.update()

    if(result) {
        res.status(200).json({
            code : 200,
            message : 'OK'
        })
    } else {
        res.status(400).json({
            code : 400,
            message : 'erreur delete nature'
        })
    }
}

const getAllNature = async(req, res) => {
    const natureRecette = new NatureRecette({})
    const result = await natureRecette.getAllNature()
    json.status(200).json({
        code : 200,
        message : 'OK',
        data : result
    })
}

module.exports = {insertNatureRecette, updateNatureRecette, getAllNature, deleteNature}